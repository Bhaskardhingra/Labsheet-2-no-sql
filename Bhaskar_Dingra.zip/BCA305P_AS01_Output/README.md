# BCA305P-AS01 — Lab Sheet 2: NoSQL Database Design
Complete sample solutions for all 15 lab questions. Examples use fictional student data.
Run each file in the matching database environment. Distributed setups (sharding/replication) require multiple services or a local multi-node lab; configuration examples and verification commands are included.

## Contents
- `01_mysql_mongodb_comparison.sql` — MySQL table, 5 records, and comparison notes
- `02_mongodb_students.js` — MongoDB CRUD operations
- `03_mongodb_orders.js` — embedded order documents and aggregation
- `04_redis_students.txt` — Redis commands
- `05_cassandra_students.cql` — Cassandra keyspace/table and operations
- `06_hbase_students.txt` — HBase shell commands
- `07_neo4j_student_course.cypher` — graph creation and queries
- `08_database_comparison.md` — MongoDB vs Cassandra vs Neo4j
- `09_single_server_mongodb.md` — local deployment / CRUD checklist
- `10_mongodb_sharding.md` — sharding demo plan and commands
- `11_mongodb_replication.md` — primary-secondary replica set demo
- `12_cassandra_peer_to_peer.md` — peer-to-peer replication demo
- `13_sharding_replication_architecture.md` — combined architecture
- `14_mapreduce_mongodb.js` — course counts and average marks
- `15_distribution_models.md` — diagrams, distribution, failure handling, pros/limits

## Notes
- MongoDB shell commands are intended for `mongosh`.
- `mongod` and `mongos` configuration varies by OS/version.
- The Redis, Cassandra, HBase and Neo4j files are scripts/commands to run in their respective shells.
- For MongoDB's legacy MapReduce API, support depends on server version; a modern aggregation equivalent is also included.

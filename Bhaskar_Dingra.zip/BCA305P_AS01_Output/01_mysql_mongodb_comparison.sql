-- MySQL / RDBMS example
CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

DROP TABLE IF EXISTS Student;
CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(80) NOT NULL,
    Course VARCHAR(60) NOT NULL,
    Semester INT NOT NULL,
    Marks DECIMAL(5,2) NOT NULL
);

INSERT INTO Student (Student_ID, Name, Course, Semester, Marks) VALUES
(101, 'Aarav Sharma', 'BCA', 3, 86.50),
(102, 'Diya Verma', 'BCA', 3, 91.00),
(103, 'Kabir Singh', 'BSc IT', 2, 78.00),
(104, 'Meera Joshi', 'BCom', 4, 82.50),
(105, 'Ishaan Gupta', 'BCA', 3, 88.00);

SELECT * FROM Student;

-- Equivalent MongoDB documents (run separately in mongosh):
-- use CollegeDB
-- db.Students.insertMany([
--   {Student_ID:101, Name:"Aarav Sharma", Course:"BCA", Semester:3, Marks:86.5},
--   {Student_ID:102, Name:"Diya Verma", Course:"BCA", Semester:3, Marks:91},
--   {Student_ID:103, Name:"Kabir Singh", Course:"BSc IT", Semester:2, Marks:78},
--   {Student_ID:104, Name:"Meera Joshi", Course:"BCom", Semester:4, Marks:82.5},
--   {Student_ID:105, Name:"Ishaan Gupta", Course:"BCA", Semester:3, Marks:88}
-- ]);

-- Comparison:
-- Schema: MySQL has a predefined table schema; MongoDB documents can vary.
-- Storage: MySQL stores rows in tables; MongoDB stores BSON documents in collections.
-- Flexibility: SQL changes generally require schema migration; document fields can be added per document.
-- Scalability: MySQL commonly scales vertically and can be clustered; MongoDB supports sharding for horizontal scaling.

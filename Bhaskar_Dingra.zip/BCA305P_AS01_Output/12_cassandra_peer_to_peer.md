# Question 12 — Cassandra peer-to-peer replication

Cassandra nodes are peers; there is no fixed master for all writes. Use a multi-node Cassandra cluster for a real demonstration.

```sql
CREATE KEYSPACE IF NOT EXISTS CollegeP2P
WITH replication = {'class':'SimpleStrategy', 'replication_factor':3};

USE CollegeP2P;
CREATE TABLE IF NOT EXISTS Students (
  Student_ID int PRIMARY KEY, Name text, Course text, Marks double
);
INSERT INTO Students (Student_ID, Name, Course, Marks)
VALUES (401, 'Arjun', 'BCA', 87.5);
SELECT * FROM Students;
```

Verification commands (run at a node with Cassandra tools configured):
- `nodetool status` — show nodes and status.
- `nodetool getendpoints CollegeP2P Students 401` — show replica endpoints for the partition (syntax can vary by version).
- Query the record through another healthy node.

Replication factor 3 means three replicas per partition when the cluster has enough eligible nodes. Peer-to-peer differs from primary-secondary replication because nodes share responsibility and clients can contact different nodes; consistency is controlled by the selected consistency level.

# Question 11 — Primary-secondary replication with MongoDB replica set

A replica set needs separate `mongod` instances with unique ports and data directories. Example local ports: 27017, 27018, 27019. Start each with the same replica-set name, e.g. `--replSet rsLab`.

Connect to one member and initialize:
```javascript
rs.initiate({
  _id:"rsLab",
  members:[
    {_id:0, host:"localhost:27017"},
    {_id:1, host:"localhost:27018"},
    {_id:2, host:"localhost:27019"}
  ]
})
rs.status()
```
Insert data on the PRIMARY:
```javascript
use CollegeReplicaDB
db.Students.insertOne({Student_ID:301, Name:"Anaya", Course:"BCA", Marks:89})
```
Connect to a secondary and run `rs.secondaryOk()` (or the version-appropriate read preference), then `db.Students.find()` to verify replication.

## If primary becomes unavailable
The remaining voting members can elect an eligible secondary as the new primary if a majority is available. Writes pause during election; if a majority is unavailable, the set cannot elect a primary. This is primary-secondary replication, not a single-server configuration.

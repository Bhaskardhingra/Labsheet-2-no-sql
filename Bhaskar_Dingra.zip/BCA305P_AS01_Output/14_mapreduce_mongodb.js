use('CollegeDB');

db.MapReduceStudents.drop();
db.MapReduceStudents.insertMany([
 {Student_ID:101, Name:"Aarav", Course:"BCA", Marks:86.5},
 {Student_ID:102, Name:"Diya", Course:"BCA", Marks:91},
 {Student_ID:103, Name:"Kabir", Course:"BSc IT", Marks:78},
 {Student_ID:104, Name:"Meera", Course:"BCom", Marks:82.5},
 {Student_ID:105, Name:"Ishaan", Course:"BCA", Marks:88},
 {Student_ID:106, Name:"Tara", Course:"BSc IT", Marks:84}
]);

// Modern aggregation equivalent: emits per-course count and average marks.
db.MapReduceStudents.aggregate([
 {$group:{
   _id:"$Course",
   studentCount:{$sum:1},
   averageMarks:{$avg:"$Marks"},
   mappedMarks:{$push:"$Marks"}
 }},
 {$project:{
   _id:0, Course:"$_id", studentCount:1, averageMarks:{$round:["$averageMarks",2]},
   MapOutput:{$map:{input:"$mappedMarks", as:"m", in:{course:"$_id", marks:"$$m"}}}
 }},
 {$sort:{Course:1}}
]);

// Legacy MapReduce demonstration (only if supported by your MongoDB version):
// var mapFunction = function(){ emit(this.Course, {count:1, total:this.Marks}); };
// var reduceFunction = function(key, values) {
//   var result = {count:0, total:0};
//   values.forEach(function(v){ result.count += v.count; result.total += v.total; });
//   return result;
// };
// db.MapReduceStudents.mapReduce(mapFunction, reduceFunction, {out:"CourseStats"});
// db.CourseStats.find();

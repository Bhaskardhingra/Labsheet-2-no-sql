# Question 10 — MongoDB sharding demo (20 records)

Sharding requires a sharded cluster with config servers, `mongos`, and at least two shards. Do not run the following in a standalone `mongod`.

## Sample dataset
Run through `mongosh` connected to `mongos`:
```javascript
sh.enableSharding("CollegeShardDB")
db = db.getSiblingDB("CollegeShardDB")
const docs = [];
for (let i=1; i<=20; i++) {
  docs.push({Student_ID:i, Name:"Student"+i, Course:(i%2 ? "BCA" : "BSc IT"), Marks:60+(i%41)});
}
db.Students.insertMany(docs)
```

## Select shard key and enable sharding
A hashed `Student_ID` spreads distinct IDs more evenly for this demo:
```javascript
sh.shardCollection("CollegeShardDB.Students", {Student_ID:"hashed"})
sh.status()
db.Students.getShardDistribution()
```
Depending on cluster version and deployment, enable the database and create the sharded collection in the documented order for that version. Verify with `sh.status()` and `getShardDistribution()`.

## Benefit
Sharding distributes data and workload across multiple machines, supporting horizontal growth. Trade-offs include operational complexity and shard-key design constraints.

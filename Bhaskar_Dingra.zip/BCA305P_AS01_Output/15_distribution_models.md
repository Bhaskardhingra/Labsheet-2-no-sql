# Question 15 — Database distribution models

## 1. Single server
```text
Client ---> [One database server: all data]
```
- Data distribution: all records live on one server.
- Failure handling: server outage makes the database unavailable unless restored from backup.
- Advantage: simple and inexpensive.
- Limitation: limited horizontal scaling and a single point of failure.
- Application: small college project or local application.

## 2. Sharding
```text
Client ---> Router ---> [Shard A] [Shard B] [Shard C]
```
- Data distribution: partitions are split across multiple shards by a shard key.
- Failure handling: sharding alone does not guarantee copies; availability depends on shard replication.
- Advantage: horizontal capacity and throughput.
- Limitation: shard-key design and operations add complexity.
- Application: very large product catalogue or event dataset.

## 3. Master-slave / primary-secondary replication
```text
Client writes ---> [Primary] ---> [Secondary 1]
                              ---> [Secondary 2]
```
- Data distribution: primary accepts writes; changes replicate to secondaries.
- Failure handling: eligible secondary may be promoted/elected when the primary fails and quorum rules permit.
- Advantage: improved availability and read scaling (depending on system).
- Limitation: failover and replication lag; not necessarily write scaling.
- Application: transactional app needing a standby copy.

## 4. Peer-to-peer replication
```text
Client ---> [Node A] <----> [Node B]
              ^  \          /
              |   <------> [Node C]
```
- Data distribution: nodes share responsibility and replicate partitions according to the database design.
- Failure handling: remaining replicas can serve requests subject to replication factor and consistency settings.
- Advantage: no single fixed master; distributed scale.
- Limitation: consistency and conflict/repair behavior need careful configuration.
- Application: highly available distributed write workloads such as Cassandra-backed event data.

## 5. Sharding + replication
```text
Router ---> Shard A replica set: [Primary] [Secondary]
       ---> Shard B replica set: [Primary] [Secondary]
```
- Data distribution: each shard holds a subset of data, and each shard has replicas.
- Failure handling: a replica can take over for a failed member; losing all replicas of a shard still threatens that shard's availability.
- Advantage: combines horizontal scale with fault tolerance.
- Limitation: most complex and resource-intensive model.
- Application: large e-commerce or multi-tenant platform.

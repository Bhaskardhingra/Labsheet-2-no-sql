use('CollegeDB');

db.Students.drop();
db.Students.insertMany([
  {Student_ID:101, Name:"Aarav Sharma", Course:"BCA", Semester:3, Marks:86.5},
  {Student_ID:102, Name:"Diya Verma", Course:"BCA", Semester:3, Marks:91},
  {Student_ID:103, Name:"Kabir Singh", Course:"BSc IT", Semester:2, Marks:78},
  {Student_ID:104, Name:"Meera Joshi", Course:"BCom", Semester:4, Marks:82.5},
  {Student_ID:105, Name:"Ishaan Gupta", Course:"BCA", Semester:3, Marks:88}
]);

// 1. Display all documents
db.Students.find({}, {_id:0}).pretty();

// 2. Find students from a particular course
db.Students.find({Course:"BCA"}, {_id:0});

// 3. Update marks of a student
db.Students.updateOne({Student_ID:103}, {$set:{Marks:81}});

// 4. Delete one student (example: Student_ID 104)
db.Students.deleteOne({Student_ID:104});

// 5. Count total students
db.Students.countDocuments({});

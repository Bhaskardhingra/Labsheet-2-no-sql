# Question 13 — Sharding + replication

## Architecture
```text
                    Applications
                         |
                       mongos
                         |
                Config Server Replica Set
                         |
             +-----------+-----------+
             |                       |
          Shard 1                  Shard 2
       (replica set)             (replica set)
        P  ->  S1                 P  ->  S1
             -> S2                     -> S2
```

## Demonstration plan
1. Deploy a MongoDB sharded cluster with a config-server replica set, one `mongos`, and at least two shard replica sets.
2. Enable sharding for `CollegeCombinedDB`.
3. Create a collection with a suitable shard key, for example hashed `Student_ID`.
4. Insert 20 or more documents.
5. Use `sh.status()` and `db.Students.getShardDistribution()` to verify distribution.
6. Use `rs.status()` on each shard replica set to verify primary and secondary members.

Example commands through `mongos`:
```javascript
sh.enableSharding("CollegeCombinedDB")
db = db.getSiblingDB("CollegeCombinedDB")
sh.shardCollection("CollegeCombinedDB.Students", {Student_ID:"hashed"})
// Insert documents as in Question 10, then:
sh.status()
db.Students.getShardDistribution()
```

## Explanation
Sharding distributes partitions across shards for horizontal scalability. Replication stores copies within each shard for availability and failover. If a shard member fails, its replica set may elect another primary; if a whole shard loses all usable replicas, data on that shard may be unavailable.

use('CollegeDB');
db.Orders.drop();

db.Orders.insertMany([
 {Order_ID:5001, Customer:{Customer_ID:1, Name:"Aarav"}, Products:[{Name:"Keyboard", Price:900, Quantity:1},{Name:"Mouse", Price:400, Quantity:2}]},
 {Order_ID:5002, Customer:{Customer_ID:2, Name:"Diya"}, Products:[{Name:"Monitor", Price:8500, Quantity:1}]},
 {Order_ID:5003, Customer:{Customer_ID:1, Name:"Aarav"}, Products:[{Name:"USB Drive", Price:600, Quantity:3}]},
 {Order_ID:5004, Customer:{Customer_ID:3, Name:"Kabir"}, Products:[{Name:"Headphones", Price:1500, Quantity:2}]},
 {Order_ID:5005, Customer:{Customer_ID:4, Name:"Meera"}, Products:[{Name:"Webcam", Price:2200, Quantity:1},{Name:"Mouse", Price:400, Quantity:1}]}
]);

// 1. Inserted five orders; display them
db.Orders.find({}, {_id:0}).pretty();

// 2. Orders for a particular customer
db.Orders.find({"Customer.Name":"Aarav"}, {_id:0});

// 3. Update product quantity in an order
db.Orders.updateOne(
  {Order_ID:5001, "Products.Name":"Mouse"},
  {$set:{"Products.$.Quantity":3}}
);

// 4. Calculate total amount per order using aggregation
db.Orders.aggregate([
  {$unwind:"$Products"},
  {$group:{_id:"$Order_ID", Customer:{$first:"$Customer.Name"},
    TotalAmount:{$sum:{$multiply:["$Products.Price","$Products.Quantity"]}}}},
  {$sort:{_id:1}}
]);

// 5. Display orders whose total is above 2000
db.Orders.aggregate([
  {$unwind:"$Products"},
  {$group:{_id:"$Order_ID", Customer:{$first:"$Customer.Name"},
    TotalAmount:{$sum:{$multiply:["$Products.Price","$Products.Quantity"]}}}},
  {$match:{TotalAmount:{$gt:2000}}},
  {$sort:{TotalAmount:-1}}
]);

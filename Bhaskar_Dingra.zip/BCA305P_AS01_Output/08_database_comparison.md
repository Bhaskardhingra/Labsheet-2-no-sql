# Question 8 — MongoDB, Cassandra and Neo4j

| Feature | MongoDB | Cassandra | Neo4j |
|---|---|---|---|
| Data model | Document (BSON) | Wide-column / partitioned rows | Property graph |
| Storage structure | Collections of documents | Tables partitioned by partition key across nodes | Nodes and relationships with properties |
| Query method | MongoDB Query API and aggregation pipeline | CQL (Cassandra Query Language) | Cypher |
| Scalability | Horizontal scaling through sharding; replica sets for availability | Distributed peer-to-peer design; add nodes to scale | Clustering options; graph traversal performance depends on graph and workload |
| Suitable applications | Content/catalog data, profiles, flexible records | High-write, time-series, event and globally distributed workloads | Social networks, recommendations, fraud detection, connected data |

For the student dataset, MongoDB represents each student as a document, Cassandra stores a row keyed by Student_ID (and query-specific tables), and Neo4j represents students and courses as nodes connected by ENROLLED_IN relationships.

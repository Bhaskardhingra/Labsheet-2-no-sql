# Question 9 — Single-server MongoDB deployment

## Steps
1. Install MongoDB Community Server and `mongosh` for your operating system.
2. Start the service using the OS service manager, or run `mongod --dbpath <data-directory>` after creating the data directory.
3. Connect with `mongosh`.
4. Run the following commands:

```javascript
use CollegeLocal
db.Students.insertMany([
 {Student_ID:201, Name:"Nisha", Course:"BCA", Marks:84},
 {Student_ID:202, Name:"Rohan", Course:"BSc IT", Marks:79},
 {Student_ID:203, Name:"Tara", Course:"BCA", Marks:92}
])
db.Students.find()
db.Students.find({Course:"BCA"})
db.Students.updateOne({Student_ID:202}, {$set:{Marks:82}})
db.Students.deleteOne({Student_ID:203})
db.Students.countDocuments()
```

## Verification
The `find` commands show inserted records, the update changes Rohan's marks to 82, the delete removes Student_ID 203, and `countDocuments()` returns the remaining count. This is a single-server setup, so it does not provide automatic failover by itself.

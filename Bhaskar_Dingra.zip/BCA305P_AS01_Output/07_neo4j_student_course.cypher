// Create at least five students and three courses
CREATE
 (s1:Student {student_id:101, name:'Aarav Sharma'}),
 (s2:Student {student_id:102, name:'Diya Verma'}),
 (s3:Student {student_id:103, name:'Kabir Singh'}),
 (s4:Student {student_id:104, name:'Meera Joshi'}),
 (s5:Student {student_id:105, name:'Ishaan Gupta'}),
 (c1:Course {name:'BCA'}),
 (c2:Course {name:'BSc IT'}),
 (c3:Course {name:'BCom'}),
 (s1)-[:ENROLLED_IN]->(c1),
 (s2)-[:ENROLLED_IN]->(c1),
 (s3)-[:ENROLLED_IN]->(c2),
 (s4)-[:ENROLLED_IN]->(c3),
 (s5)-[:ENROLLED_IN]->(c1);

// Display all students
MATCH (s:Student) RETURN s;

// Find students enrolled in BCA
MATCH (s:Student)-[:ENROLLED_IN]->(c:Course {name:'BCA'})
RETURN s.student_id, s.name;

// All courses taken by a particular student
MATCH (s:Student {student_id:101})-[:ENROLLED_IN]->(c:Course)
RETURN s.name, c.name;

// Add a relationship
MATCH (s:Student {student_id:103}), (c:Course {name:'BCA'})
MERGE (s)-[:ENROLLED_IN]->(c);

// Remove a relationship
MATCH (s:Student {student_id:103})-[r:ENROLLED_IN]->(c:Course {name:'BCA'})
DELETE r;
